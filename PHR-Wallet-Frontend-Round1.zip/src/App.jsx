import { useState } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Records from "./pages/Records";
import AddRecord from "./pages/AddRecord";
import TimelinePage from "./pages/TimelinePage";
import Profile from "./pages/Profile";
import Layout from "./components/Layout";

export default function App() {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("phrUser");
    return saved ? JSON.parse(saved) : null;
  });

  const login = (email, role) => {
    const newUser = {
      id: role === "PATIENT" ? 1 : 2,
      name: role === "PATIENT" ? "Snehitha" : "Dr. Rao",
      email,
      role
    };
    localStorage.setItem("phrUser", JSON.stringify(newUser));
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem("phrUser");
    setUser(null);
  };

  if (!user) {
    return (
      <Routes>
        <Route path="*" element={<Login onLogin={login} />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route element={<Layout user={user} onLogout={logout} />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard user={user} />} />
        <Route path="/records" element={<Records user={user} />} />
        <Route path="/add-record" element={<AddRecord user={user} />} />
        <Route path="/timeline" element={<TimelinePage user={user} />} />
        <Route path="/profile" element={<Profile user={user} />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}