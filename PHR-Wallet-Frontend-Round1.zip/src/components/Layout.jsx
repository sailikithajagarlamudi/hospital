import { Outlet, NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, FileText, PlusCircle, Clock3, UserCircle,
  LogOut, Menu, X, HeartPulse
} from "lucide-react";
import { useState } from "react";

export default function Layout({ user, onLogout }) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const links = [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/records", label: "Medical Records", icon: FileText },
    { to: "/timeline", label: "Health Timeline", icon: Clock3 },
    { to: "/add-record", label: "Add Record", icon: PlusCircle },
    { to: "/profile", label: "Profile", icon: UserCircle }
  ];

  const logout = () => {
    onLogout();
    navigate("/");
  };

  return (
    <div className="app-shell">
      <header className="mobile-header">
        <button className="icon-btn" onClick={() => setOpen(!open)}>
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
        <div className="brand compact"><HeartPulse size={22} /> PHR Wallet</div>
      </header>

      <aside className={`sidebar ${open ? "show" : ""}`}>
        <div className="brand">
          <div className="brand-icon"><HeartPulse size={24} /></div>
          <div>
            <strong>PHR Wallet</strong>
            <span>Personal Health Records</span>
          </div>
        </div>

        <div className="profile-mini">
          <div className="avatar">{user.name.charAt(0)}</div>
          <div>
            <strong>{user.name}</strong>
            <span>{user.role}</span>
          </div>
        </div>

        <nav>
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setOpen(false)}
              className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}
            >
              <Icon size={19} />
              {label}
            </NavLink>
          ))}
        </nav>

        <button className="logout-btn" onClick={logout}>
          <LogOut size={19} /> Logout
        </button>
      </aside>

      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}