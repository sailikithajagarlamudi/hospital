import { CalendarDays, UserRound, Pill, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function RecordCard({ record }) {
  const navigate = useNavigate();

  return (
    <div className="record-card">
      <div className="record-date">
        <CalendarDays size={18} />
        {record.visitDate}
      </div>
      <h3>{record.report}</h3>
      <div className="record-meta">
        <span><UserRound size={15} /> {record.doctor}</span>
        <span><Pill size={15} /> {record.medicine}</span>
      </div>
      <p>{record.notes}</p>
      <button className="outline-btn" onClick={() => navigate("/records")}>
        <FileText size={16} /> View Record
      </button>
    </div>
  );
}