import axios from "axios";

// Round 1 frontend currently uses demo data.
// In the next step, change this baseURL to your Spring Boot server
// and use api.get/api.post in the pages.
const api = axios.create({
  baseURL: "http://localhost:8080/api",
  headers: {
    "Content-Type": "application/json"
  }
});

export default api;