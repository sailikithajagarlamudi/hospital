import { useState } from "react";
import { Save, CheckCircle2, AlertCircle } from "lucide-react";

export default function AddRecord() {
  const [form, setForm] = useState({
    visitDate: "",
    doctor: "",
    report: "",
    medicine: "",
    notes: ""
  });
  const [message, setMessage] = useState(null);

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  const submit = e => {
    e.preventDefault();
    setMessage(null);

    if (!form.visitDate || !form.doctor || !form.report) {
      setMessage({ type: "error", text: "Visit date, doctor name and report are required." });
      return;
    }

    setMessage({ type: "success", text: "Medical record saved successfully! (Frontend demo)" });
    setForm({ visitDate: "", doctor: "", report: "", medicine: "", notes: "" });
  };

  return (
    <div>
      <div className="topbar">
        <div>
          <p className="eyebrow">NEW ENTRY</p>
          <h1>Add Medical Record</h1>
          <p className="muted">Enter visit information carefully. Required fields are marked.</p>
        </div>
      </div>

      <div className="form-card">
        {message && (
          <div className={message.type === "success" ? "success-box" : "error-box"}>
            {message.type === "success" ? <CheckCircle2 size={18}/> : <AlertCircle size={18}/>}
            {message.text}
          </div>
        )}

        <form onSubmit={submit} className="medical-form">
          <div className="form-grid">
            <div>
              <label>Visit Date *</label>
              <input type="date" value={form.visitDate} onChange={e => update("visitDate", e.target.value)} />
            </div>
            <div>
              <label>Doctor Name *</label>
              <input value={form.doctor} onChange={e => update("doctor", e.target.value)} placeholder="e.g. Dr. Rao" />
            </div>
            <div>
              <label>Report *</label>
              <input value={form.report} onChange={e => update("report", e.target.value)} placeholder="e.g. Blood Test" />
            </div>
            <div>
              <label>Medicine</label>
              <input value={form.medicine} onChange={e => update("medicine", e.target.value)} placeholder="Medicine name" />
            </div>
          </div>

          <div>
            <label>Notes</label>
            <textarea rows="6" value={form.notes} onChange={e => update("notes", e.target.value)} placeholder="Add observations, instructions or follow-up notes..." />
          </div>

          <div className="form-actions">
            <button className="primary-btn" type="submit"><Save size={18}/> Save Record</button>
          </div>
        </form>
      </div>
    </div>
  );
}