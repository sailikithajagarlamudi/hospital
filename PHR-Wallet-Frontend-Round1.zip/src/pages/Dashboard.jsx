import { useState } from "react";
import { HeartPulse, Stethoscope, Pill, FileText, ArrowRight, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StatCard from "../components/StatCard";
import RecordCard from "../components/RecordCard";

const sampleRecords = [
  { id: 1, visitDate: "05 Oct 2026", doctor: "Dr. Rao", report: "Blood Test", medicine: "ABC", notes: "Follow-up required after five days." },
  { id: 2, visitDate: "20 Sep 2026", doctor: "Dr. Kumar", report: "General Checkup", medicine: "XYZ", notes: "Routine health checkup." },
  { id: 3, visitDate: "10 Aug 2026", doctor: "Dr. Priya", report: "Fever Treatment", medicine: "Paracetamol", notes: "Rest and hydration advised." }
];

export default function Dashboard({ user }) {
  const navigate = useNavigate();
  const [records] = useState(sampleRecords);

  return (
    <div>
      <div className="topbar">
        <div>
          <p className="eyebrow">PERSONAL HEALTH RECORD</p>
          <h1>Good morning, {user.name} 👋</h1>
          <p className="muted">Here is an overview of your health records.</p>
        </div>
        <button className="primary-btn" onClick={() => navigate("/add-record")}><Plus size={18}/> Add Record</button>
      </div>

      <div className="stats-grid">
        <StatCard icon={<HeartPulse />} label="Medical Visits" value="5" note="All time" />
        <StatCard icon={<Stethoscope />} label="Doctors" value="3" note="Connected" />
        <StatCard icon={<Pill />} label="Medicines" value="4" note="Recent records" />
        <StatCard icon={<FileText />} label="Reports" value="7" note="Available" />
      </div>

      <section className="section">
        <div className="section-heading">
          <div>
            <h2>Recent Medical Records</h2>
            <p className="muted">Your latest health activity.</p>
          </div>
          <button className="text-btn" onClick={() => navigate("/records")}>View all <ArrowRight size={16}/></button>
        </div>

        <div className="record-grid">
          {records.map(record => <RecordCard key={record.id} record={record} />)}
        </div>
      </section>

      <section className="info-banner">
        <div>
          <strong>Health timeline is ready</strong>
          <p>View your medical history in chronological order.</p>
        </div>
        <button className="outline-btn" onClick={() => navigate("/timeline")}>Open Timeline</button>
      </section>
    </div>
  );
}