import { UserCircle, Mail, ShieldCheck, Stethoscope } from "lucide-react";

export default function Profile({ user }) {
  return (
    <div>
      <div className="topbar">
        <div>
          <p className="eyebrow">ACCOUNT</p>
          <h1>Profile</h1>
          <p className="muted">Your PHR Wallet account information.</p>
        </div>
      </div>

      <div className="profile-card">
        <div className="large-avatar">{user.name.charAt(0)}</div>
        <h2>{user.name}</h2>
        <span className="status-pill">{user.role}</span>

        <div className="profile-details">
          <div><Mail size={18}/><span>{user.email}</span></div>
          <div><ShieldCheck size={18}/><span>Role-based access enabled</span></div>
          <div><Stethoscope size={18}/><span>PHR Wallet member</span></div>
        </div>
      </div>
    </div>
  );
}