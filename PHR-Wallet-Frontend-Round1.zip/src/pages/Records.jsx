import { Search, FileText, CalendarDays, UserRound, Download } from "lucide-react";
import { useMemo, useState } from "react";

const recordsData = [
  { id: 1, visitDate: "05 Oct 2026", doctor: "Dr. Rao", report: "Blood Test", medicine: "ABC", notes: "Follow-up required after five days." },
  { id: 2, visitDate: "20 Sep 2026", doctor: "Dr. Kumar", report: "General Checkup", medicine: "XYZ", notes: "Routine health checkup." },
  { id: 3, visitDate: "10 Aug 2026", doctor: "Dr. Priya", report: "Fever Treatment", medicine: "Paracetamol", notes: "Rest and hydration advised." },
  { id: 4, visitDate: "18 Jun 2026", doctor: "Dr. Rao", report: "Health Checkup", medicine: "Vitamin D", notes: "Regular follow-up." }
];

export default function Records() {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return recordsData.filter(r =>
      `${r.doctor} ${r.report} ${r.medicine} ${r.visitDate}`.toLowerCase().includes(q)
    );
  }, [query]);

  const downloadSummary = (r) => {
    const text = `PHR WALLET - MEDICAL RECORD SUMMARY

Date: ${r.visitDate}
Doctor: ${r.doctor}
Report: ${r.report}
Medicine: ${r.medicine}
Notes: ${r.notes}
`;
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `medical-record-${r.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="topbar">
        <div>
          <p className="eyebrow">HEALTH RECORDS</p>
          <h1>Medical Records</h1>
          <p className="muted">View, search and manage your medical history.</p>
        </div>
      </div>

      <div className="search-box">
        <Search size={19} />
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search doctor, report, medicine..." />
      </div>

      <div className="record-list">
        {filtered.map(r => (
          <article className="record-row" key={r.id}>
            <div className="record-symbol"><FileText size={22}/></div>
            <div className="record-main">
              <div className="record-title-line">
                <h3>{r.report}</h3>
                <span className="status-pill">Available</span>
              </div>
              <div className="record-meta">
                <span><CalendarDays size={15}/>{r.visitDate}</span>
                <span><UserRound size={15}/>{r.doctor}</span>
              </div>
              <p>{r.notes}</p>
            </div>
            <button className="outline-btn" onClick={() => downloadSummary(r)}>
              <Download size={16}/> Summary
            </button>
          </article>
        ))}
        {filtered.length === 0 && <div className="empty-state">No records found.</div>}
      </div>
    </div>
  );
}