import { useState } from "react";
import { HeartPulse, ShieldCheck, LockKeyhole, Mail, Stethoscope } from "lucide-react";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("patient@phr.com");
  const [password, setPassword] = useState("123456");
  const [role, setRole] = useState("PATIENT");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    setError("");

    if (!email.trim() || !password.trim()) {
      setError("Email and password are required.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin(email, role);
    }, 700);
  };

  return (
    <div className="login-page">
      <div className="login-decoration">
        <div className="hero-badge"><ShieldCheck size={18} /> Secure Health Records</div>
        <h1>Your health records, organized in one place.</h1>
        <p>PHR Wallet helps patients and authorized healthcare professionals access medical information quickly and clearly.</p>
        <div className="feature-row">
          <span><HeartPulse size={17}/> Health Timeline</span>
          <span><LockKeyhole size={17}/> Role Based Access</span>
          <span><Stethoscope size={17}/> Doctor Records</span>
        </div>
      </div>

      <div className="login-card">
        <div className="login-logo"><HeartPulse size={30} /></div>
        <h2>Welcome to PHR Wallet</h2>
        <p className="muted">Sign in to manage your personal health records.</p>

        <form onSubmit={submit}>
          <label>Email</label>
          <div className="input-wrap">
            <Mail size={18} />
            <input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="Enter email" />
          </div>

          <label>Password</label>
          <div className="input-wrap">
            <LockKeyhole size={18} />
            <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Enter password" />
          </div>

          <label>Login as</label>
          <div className="role-switch">
            <button type="button" className={role === "PATIENT" ? "selected" : ""} onClick={() => setRole("PATIENT")}>Patient</button>
            <button type="button" className={role === "DOCTOR" ? "selected" : ""} onClick={() => setRole("DOCTOR")}>Doctor</button>
          </div>

          {error && <div className="error-box">{error}</div>}

          <button className="primary-btn full" disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="demo-hint">
          Demo: patient@phr.com / 123456
        </div>
      </div>
    </div>
  );
}