import { CalendarDays, UserRound, Pill, FileText } from "lucide-react";

const events = [
  { date: "05 Oct 2026", doctor: "Dr. Rao", report: "Blood Test", medicine: "ABC", notes: "Follow-up required after five days." },
  { date: "20 Sep 2026", doctor: "Dr. Kumar", report: "General Checkup", medicine: "XYZ", notes: "Routine health checkup." },
  { date: "10 Aug 2026", doctor: "Dr. Priya", report: "Fever Treatment", medicine: "Paracetamol", notes: "Rest and hydration advised." },
  { date: "18 Jun 2026", doctor: "Dr. Rao", report: "Health Checkup", medicine: "Vitamin D", notes: "Regular follow-up." }
];

export default function TimelinePage() {
  return (
    <div>
      <div className="topbar">
        <div>
          <p className="eyebrow">MEDICAL HISTORY</p>
          <h1>Health Timeline</h1>
          <p className="muted">A chronological view of your medical journey.</p>
        </div>
      </div>

      <div className="timeline">
        {events.map((event, index) => (
          <div className="timeline-item" key={index}>
            <div className="timeline-dot"><CalendarDays size={15}/></div>
            <div className="timeline-content">
              <span className="timeline-date">{event.date}</span>
              <h3>{event.report}</h3>
              <div className="record-meta">
                <span><UserRound size={15}/>{event.doctor}</span>
                <span><Pill size={15}/>{event.medicine}</span>
              </div>
              <p>{event.notes}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}