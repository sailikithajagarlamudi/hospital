# PHR Wallet - Round 1 Frontend

Personal Health Record (PHR) Wallet frontend for the hackathon.

## Current features
- React + Vite
- Responsive UI/UX
- Login screen with Patient/Doctor demo roles
- Dashboard
- Medical records list
- Search/filter
- Add medical record form with validation
- Health timeline
- Profile page
- View/downloadable text summary
- Loading, success and error states

## Demo login
Patient: patient@phr.com / 123456
Doctor: doctor@phr.com / 123456

## Run
```bash
npm install
npm run dev
```

The current version uses frontend demo data. The next integration step is to connect it to the Java 17 + Spring Boot + MySQL REST backend.
